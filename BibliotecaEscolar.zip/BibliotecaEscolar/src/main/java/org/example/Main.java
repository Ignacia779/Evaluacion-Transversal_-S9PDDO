import dao.UsuarioDAO;
import dao.LibroDAO;
import dao.DatabaseConnection;
import model.Usuario;
import model.Libro;
import java.sql.Connection;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        List<Usuario> usuarios = usuarioDAO.listarUsuarios();
        for (Usuario u : usuarios) {
            System.out.println(u);
        }

        LibroDAO libroDAO = new LibroDAO();
        List<Libro> libros = libroDAO.listarLibros();
        for (Libro l : libros) {
            System.out.println(l);
        }

        // Probar conexión
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            if (conn != null) {
                System.out.println("✅ Conexión establecida correctamente");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



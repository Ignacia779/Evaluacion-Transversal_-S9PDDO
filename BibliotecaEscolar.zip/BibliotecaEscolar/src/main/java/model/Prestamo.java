package model;

import java.sql.Date;

public class Prestamo {
    private int id;
    private int estudianteId;
    private int libroId;
    private Date fechaPrestamo;
    private Date fechaDevolucion;

    public Prestamo() {}

    public Prestamo(int id, int estudianteId, int libroId, Date fechaPrestamo, Date fechaDevolucion) {
        this.id = id;
        this.estudianteId = estudianteId;
        this.libroId = libroId;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
    }

    public int getId() { return id; }
    public int getEstudianteId() { return estudianteId; }
    public int getLibroId() { return libroId; }
    public Date getFechaPrestamo() { return fechaPrestamo; }
    public Date getFechaDevolucion() { return fechaDevolucion; }

    @Override
    public String toString() {
        return "Prestamo{" +
                "id=" + id +
                ", estudianteId=" + estudianteId +
                ", libroId=" + libroId +
                ", fechaPrestamo=" + fechaPrestamo +
                ", fechaDevolucion=" + fechaDevolucion +
                '}';
    }
}

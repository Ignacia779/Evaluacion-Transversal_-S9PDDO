package app;

import dao.UsuarioDAO;
import dao.LibroDAO;
import dao.EstudianteDAO;
import dao.PrestamoDAO;
import dao.DatabaseConnection;
import model.Usuario;
import model.Libro;
import model.Estudiante;
import model.Prestamo;
import java.sql.Connection;
import java.sql.Date;
import java.util.List;
public class Main {
    public static void main(String[] args) {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        List<Usuario> usuarios = usuarioDAO.listarUsuarios();
        for (Usuario u : usuarios) {
            System.out.println(u);
        }

        LibroDAO libroDAO = new LibroDAO();
        List<Libro> libros = libroDAO.listarLibros();
        for (Libro l : libros) {
            System.out.println(l);
        }

        EstudianteDAO estudianteDAO = new EstudianteDAO();
        List<Estudiante> estudiantes = estudianteDAO.listarEstudiantes();
        for (Estudiante e : estudiantes) {
            System.out.println(e);
        }
        PrestamoDAO prestamoDAO = new PrestamoDAO();
        List<Prestamo> prestamos = prestamoDAO.listarPrestamos();
        for (Prestamo p : prestamos) {
            System.out.println(p);
        }

        List<String> prestamosDetallados = prestamoDAO.listarPrestamosDetallados();
        for (String detalle : prestamosDetallados) {
            System.out.println(detalle);
        }

        prestamoDAO.agregarPrestamo(1, 2, Date.valueOf("2026-10-11"), null);
        prestamoDAO.registrarDevolucion(2, Date.valueOf("2026-10-20"));
        prestamoDAO.eliminarPrestamo(1);

        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            if (conn != null) {
                System.out.println("✅ Conexión establecida correctamente");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
package dao;

import model.Prestamo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PrestamoDAO {

    // Listar préstamos con IDs (básico)
    public List<Prestamo> listarPrestamos() {
        List<Prestamo> prestamos = new ArrayList<>();
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT id, estudiante_id, libro_id, fecha_prestamo, fecha_devolucion FROM prestamos");

            while (rs.next()) {
                Prestamo p = new Prestamo(
                        rs.getInt("id"),
                        rs.getInt("estudiante_id"),
                        rs.getInt("libro_id"),
                        rs.getDate("fecha_prestamo"),
                        rs.getDate("fecha_devolucion")
                );
                prestamos.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prestamos;
    }

    // Listar préstamos detallados con JOIN (nombre estudiante + título libro)
    public List<String> listarPrestamosDetallados() {
        List<String> prestamos = new ArrayList<>();
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "SELECT p.id, e.nombre AS estudiante, l.titulo AS libro, " +
                    "p.fecha_prestamo, p.fecha_devolucion " +
                    "FROM prestamos p " +
                    "JOIN estudiantes e ON p.estudiante_id = e.id " +
                    "JOIN libros l ON p.libro_id = l.id";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String detalle = "Préstamo{id=" + rs.getInt("id") +
                        ", estudiante='" + rs.getString("estudiante") + '\'' +
                        ", libro='" + rs.getString("libro") + '\'' +
                        ", fechaPrestamo=" + rs.getDate("fecha_prestamo") +
                        ", fechaDevolucion=" + rs.getDate("fecha_devolucion") +
                        '}';
                prestamos.add(detalle);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prestamos;
    }

    // Insertar un nuevo préstamo
    public void agregarPrestamo(int estudianteId, int libroId, Date fechaPrestamo, Date fechaDevolucion) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "INSERT INTO prestamos (estudiante_id, libro_id, fecha_prestamo, fecha_devolucion) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, estudianteId);
            ps.setInt(2, libroId);
            ps.setDate(3, fechaPrestamo);
            ps.setDate(4, fechaDevolucion);
            ps.executeUpdate();
            System.out.println("✅ Préstamo agregado correctamente");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void registrarDevolucion(int prestamoId, Date fechaDevolucion) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "UPDATE prestamos SET fecha_devolucion = ? WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, fechaDevolucion);
            ps.setInt(2, prestamoId);
            ps.executeUpdate();
            System.out.println("✅ Devolución registrada correctamente");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void eliminarPrestamo(int prestamoId) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "DELETE FROM prestamos WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, prestamoId);
            ps.executeUpdate();
            System.out.println("✅ Préstamo eliminado correctamente");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}